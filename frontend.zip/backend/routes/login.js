// backend/routes/login.js

const path = require('path');
const express = require('express');
const router = express.Router();

// Login route
router.get('/', (req, res) => {
    // Assuming login.html is in the frontend directory
    const loginFilePath = path.join(__dirname, '..', 'frontend', 'login.html');
    
    res.sendFile(loginFilePath);
});

module.exports = router;