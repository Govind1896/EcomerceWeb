// backend/routes/contactus.js

const express = require('express');
const router = express.Router();

// Contact Us route
router.get('/', (req, res) => {
    res.send('Welcome to the contact us page!');
});

module.exports = router;