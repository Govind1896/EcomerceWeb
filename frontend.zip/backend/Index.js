const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const PORT = process.env.PORT || 3000;

// Connect to MongoDB (replace 'your-connection-string' with your actual connection string)
mongoose.connect('mongodb+srv://admin:Admin%40123@cluster0.hecptbk.mongodb.net/Govind', { useNewUrlParser: true, useUnifiedTopology: true });

// MongoDB Connection Events
mongoose.connection.on('connected', () => {
  console.log('Connected to MongoDB');
});

mongoose.connection.on('error', (err) => {
  console.error('MongoDB connection error:', err);
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files from the 'frontend' directory
app.use(express.static(path.join(__dirname, '../frontend')));

// Define User model
const User = mongoose.model('User', {
  username: String,
  password: String
});

// Define routes

// Home route
app.get('/', (req, res) => {
  // Assuming you have some logic for the home route
  res.send('Home page');
});

// Showing login form
app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/login.html'));
});

// Handling user registration
app.post("/register", async (req, res) => {
  try {
    const newUser = new User({
      username: req.body.username,
      password: req.body.password
    });

    // Save the new user to the database
    await newUser.save();

    res.send('User registered successfully');
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Handling user login
app.post("/login", async (req, res) => {
  try {
    // check if the user exists
    const user = await User.findOne({ username: req.body.username });
    if (user) {
      // check if password matches
      const result = req.body.password === user.password;
      if (result) {
        res.send('Secret page');
      } else {
        res.status(400).json({ error: "Password doesn't match" });
      }
    } else {
      res.status(400).json({ error: "User doesn't exist" });
    }
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Start the server
app.listen(PORT, () => {
  console.log('Server is running on http://localhost:' + PORT);
});